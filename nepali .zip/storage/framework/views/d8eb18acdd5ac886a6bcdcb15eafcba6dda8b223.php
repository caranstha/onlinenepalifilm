


<head>

    <?php echo $__env->make('admin/jcss', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!--Dynamically creates ads markup-->
  

    <div class="container_12">

        <div class="grid_12 header-repeat">

            <div id="branding">

                <div class="floatleft">

                    <h1 alt="Logo" style="color:white;">Online Nepali Flim</h1></div>

                <div class="floatright">

                    <div class="floatleft">

                        <img src="img/img-profile.jpg" alt="Profile Pic" /></div>

                    <div class="floatleft marginleft10">

                        <ul class="inline-ul floatleft">

                            <li>Hello </li>

                            <li><a href="#">@date("y-m-d")</a></li>

                            <li><a href="logout.php?logout=logout">Logout</a></li>

                        </ul>
                        

                        <br />

                        <span class="small grey">Last Login: 3 hours ago</span>

                    </div>

                </div>

                <div class="clear">

                </div>

            </div>

        </div>

        <div class="clear">

        </div>


        <div class="grid_12">

              <ul class="nav main">

                <li class="ic-dashboard"><a href="dashboard.php"><span>Dashboard</span></a> </li>

                <li class="ic-form-style"><a href="javascript:"><span>Controls</span></a>

                    <ul>

                        <li><a href="#" >Forms</a> </li>

                        <li><a href="#">Buttons</a> </li>

                        <li><a href="#">Full Page Example</a> </li>

                        <li><a href="#">Page with Sidebar Example</a> </li>

                    </ul>

                </li>

				<li class="ic-typography"><a href="#"><span>Typography</span></a></li>

                <li class="ic-charts"><a href="#"><span>Charts & Graphs</span></a></li>

                <li class="ic-grid-tables"><a href="#"><span>Data Table</span></a></li>

                <li class="ic-gallery dd"><a href="javascript:"><span>Galleries</span></a>

               		 <ul>

                        <li><a href="#">Pretty Photo</a> </li>

                        <li><a href="#">Gallery with Filter</a> </li>

                    </ul>

                </li>

                <li class="ic-notifications"><a href="#"><span>Notifications</span></a></li>



            </ul>

        </div>

        <div class="clear">

        </div>



        </head>

        



        

@include('admin/header')
@include('admin/sidebar')
<div id="content">
        @include('admin/welcome')
            <!--@yield('content') -->  
        </div>
    </body>
</html>

<?php echo $__env->make('admin/jcss', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="grid_2">
            <div class="box sidemenu">
                <div class="block" id="section-menu">
                    <ul class="section menu">
                        <li><a class="menuitem">Customize</a>
                            <ul class="submenu">
                                <li><a>Slider</a> </li>
                                <li><a href="addfeaturemovie.php">Feature Movies</a> </li>
                                <li><a href="listmovie.php">Now Availabe</a> </li>
                                <li><a>Upcoming</a> </li>
                                <li><a href="test.php">Music Videos</a> </li>                          

                            </ul>
                        </li>

                        <li><a class="menuitem">Users</a>
                         <ul class="submenu">
                                <li><a href="adduser.php">Add New User</a> </li>
                                <li><a href="listuser.php">List Users</a> </li>
                                <li><a href="#">Delete User</a> </li>        

                         </ul>
                        </li>

                        <li><a class="menuitem">Gallery</a>
                         <ul class="submenu">

                                <li><a href="test.php">Gallery</a> </li>
                                <li><a href="addfeaturemovie.php">Add Movie</a> </li>
                                <li><a href="edit.php">Edit Movies</a> </li>
                                              

                         </ul>
                        </li>

                        <li><a class="menuitem">Slider</a>
                         <ul class="submenu">
                                <li><a href="slider.php">Add Slider</a> </li>
                                
                         </ul>

                        </li>                       

                    </ul>

                </div>

            </div>

        </div>


     >

<div id="menu">
            <table class="table">

                <tr><td> <a class="b" href="<?php echo e(url('admin/index')); ?>"> Dashboard </a></td></tr>
                <tr><td><a class="b" href="<?php echo e(url('admin/showadmin')); ?>"> Admins </a></td></tr>
                <tr><td><a class="b" href="<?php echo e(url('category/category')); ?>"> Categories </a></td></tr>
                <tr><td><a class="b" href="<?php echo e(url('genres/genres')); ?>"> Genres </a></td></tr>
                <tr> <td><a class="b" href="<?php echo e(url('movies/movies')); ?>"> Movies </a></td></tr>
                
                
                <tr> <td><a class="b" href="<?php echo e(url('add/showadd')); ?>"> Advertisment </a></td></tr>
                
                <tr><td><a class="b" href="#"> Feedback </a></td></tr>
                <tr><td><a class="b" href="#"> Transactions </a></td></tr>
             
            </table>
        </div>
<?php echo $__env->make('admin/head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin/sidemenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="content">
        <?php echo $__env->make('admin/welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!--<?php echo $__env->yieldContent('content'); ?> -->  
        </div>
    </body>
</html>

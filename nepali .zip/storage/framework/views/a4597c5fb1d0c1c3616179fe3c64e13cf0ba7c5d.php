<html>
    <head>
        <title> Admin Panel </title>  
        <link href="<?php echo e(url('lib/css/style1.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <div class="header">
            <div class="left">
                <a id="admin" href="#">Admin panel</a>
            </div>
            <div class="center">
                Welcome 
                </div>
            <div class="right">
                <a id = "logout" href="<?php echo e(url('login/logout')); ?>">LogOut</a>
            </div>
            
        </div>
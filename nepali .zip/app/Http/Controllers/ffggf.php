<!-- <script type="text/javascript">
							$(document).ready(function(){
								$('#submit1').click(function(e,){
									e.preventDefault();
									var name=$('#name').val();
									var email=$('#email').val();
									var phone_no=$('#phone_no').val();
									//alert(phone_no);
									



									var dataString = form.serialize();
									$.ajax({

										url:"{{('user/singlepage/')}}/{{}}",
										type:"POST",
										

									});
								});
							});



						</script> -->
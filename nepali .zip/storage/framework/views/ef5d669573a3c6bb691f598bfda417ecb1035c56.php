<?php echo $__env->make('admin/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="content">

<form action="<?php echo e(url('category/editcategory')); ?>/<?php echo e($result->id); ?>" method="POST">
     <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
    <p>Category name </p>

    
    <input type="text" name="category" value="<?php echo e($result->category); ?>">
    <select name='status'>

    <option value="<?php echo e($result->status); ?>" selected="selected"><?php echo e($result->status); ?></option>
    <option value="publish">Publish</option>    
    <option value="draft">Draft</option>
    </select>
    <p><input type="submit" value="Add" name="add"></p>
</form>
</div>  
</body>
</html>
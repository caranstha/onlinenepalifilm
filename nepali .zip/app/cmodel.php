<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cmodel extends Model
{
    protected $table='cmodels';
}

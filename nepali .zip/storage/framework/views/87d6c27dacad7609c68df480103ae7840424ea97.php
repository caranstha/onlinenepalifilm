<?php echo $__env->make('admin/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="content">
<a style="margin-right: 1000px;font-size: 40px;width:30%; text-decoration: none;background-color: #6699ff;" href="<?php echo e(url('movies/addmovies')); ?>" > Add movies </a>
<table border="1">
<tr>
<th style="color:#ff99cc;width:60px;font-size: 35px;">Id</th>
<th style="color:#ff99cc;width:110px;font-size: 35px;">Title</th>
<th style="color:#ff99cc;width:100px;font-size: 30px;">Category</th>
<th style="color:#ff99cc;width:100px;font-size: 30px;">Genres</th>
<th style="color:#ff99cc;width:160px;font-size: 35px;">Image</th>
<th style="color:#ff99cc;width:160px;font-size: 35px;">Link</th>
<th style="color:#ff99cc;width:130px;font-size: 35px;">Description</t>
<th style="color:#ff99cc;width:130px;font-size: 25px;">Posted By</t>
<th style="color:#ff99cc;width:160px;font-size: 35px;">Date/Time</th>
<th style="color:#ff99cc;width:90px;font-size: 25px;">Status</th>
<th style="color:#ff99cc;width:90px;font-size: 35px;">Action</th>


</tr>
<?php foreach($result as $row): ?>
<tr>
<td><?php echo e($row->id); ?></td>
<td><?php echo e($row->title); ?></td>
<td>
<?php echo e($row->category); ?></td>
<td><?php echo e($row->genres); ?>

<td><img src="<?php echo e(url($row->image)); ?>" width="100px" height="100px"></td>
<td><?php echo e($row->link); ?></td>
<td><?php echo e(str_limit($row->description,$limit=100,$end='....')); ?></td>
<td><?php echo e($row->posted_by); ?></td>
<td><?php echo e($row->created_at); ?>

</td>
<td><?php echo e($row->status); ?></td>
<td style="width:200px"><a href="<?php echo e(url('movies/editmovies')); ?>/<?php echo e($row->id); ?>" style="text-decoration: none;">Edit</a>
    |
    <a href="<?php echo e(url('movies/deletemovies')); ?>/<?php echo e($row->id); ?>" style="text-decoration: none;">Delete</a>
    |

    <a href="<?php echo e(url('movies/changestatusmovies')); ?>/<?php echo e($row->id); ?>" style="text-decoration: none;"><?php if($row->status=='publish'): ?>
           Draft
           <?php endif; ?>
           <?php if($row->status=='draft'): ?>
           Publish
           <?php endif; ?></a>
    </td>
    </tr>
<?php endforeach; ?>
</table>
</div>  
</body>
</html>





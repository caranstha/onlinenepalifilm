<div id="menu">
            <table class="table">

                <tr><td> <a class="b" href="{{url('admin/index')}}"> Dashboard </a></td></tr>
                <tr><td><a class="b" href="{{url('admin/showadmin')}}"> Admins </a></td></tr>
                <tr><td><a class="b" href="{{url('category/category')}}"> Categories </a></td></tr>
                <tr><td><a class="b" href="{{url('genres/genres')}}"> Genres </a></td></tr>
                <tr> <td><a class="b" href="{{url('movies/movies')}}"> Movies </a></td></tr>
                
                
                <tr> <td><a class="b" href="{{url('add/showadd')}}"> Advertisment </a></td></tr>
                
                <tr><td><a class="b" href="#"> Feedback </a></td></tr>
                <tr><td><a class="b" href="#"> Transactions </a></td></tr>
             
            </table>
        </div>
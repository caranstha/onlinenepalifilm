<?php echo $__env->make('admin/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="content">
<a style="margin-right: 1000px;font-size: 40px;width:30%; text-decoration: none;background-color: #6699ff;" href="<?php echo e(url('admin/addusers')); ?>" > Add Users </a>
<table border="1">
<tr>
<th style="color:#ff99cc;width:60px;font-size: 35px;">Id</th>
<th style="color:#ff99cc;width:110px;font-size: 35px;">Name</th>
<th style="color:#ff99cc;width:100px;font-size: 30px;">Email</th>
<th style="color:#ff99cc;width:100px;font-size: 30px;">Password</th>
<th style="color:#ff99cc;width:100px;font-size: 30px;">Action</th>



</tr>
<?php foreach($users as $row): ?>
<tr>
<td><?php echo e($row->id); ?></td>
<td><?php echo e($row->name); ?></td>
<td>
<?php echo e($row->email); ?></td>
<td><?php echo e($row->password); ?></td>
<td><a href="<?php echo e(url('admin/deleteusers')); ?>/<?php echo e($row->id); ?>">Delete User </td>
</tr>
<?php endforeach; ?>
</table>
</div>  
</body>
</html>





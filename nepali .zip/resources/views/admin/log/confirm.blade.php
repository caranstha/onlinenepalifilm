

<a href="{{url('log/confirm')}}/{{$result->id}}">Click here to confirm the user</a>


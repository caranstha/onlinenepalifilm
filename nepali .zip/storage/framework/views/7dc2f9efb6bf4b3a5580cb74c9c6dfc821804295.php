<?php echo $__env->make('admin/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="content">
<a href="<?php echo e(url('genres/addgenres')); ?>" style="margin-right: 1000px;text-decoration: none;font-size: 40px; hover:'color:green'" > Add Genres </a>
<table border="1">
    <tr>
        <th style="color:#ff99cc;width:40px;font-size: 30px;">Id</th>
        <th style="color:#ff99cc;width:300px;font-size: 30px;">Genres Name</th>
        <th style="color:#ff99cc;width:100px;font-size: 30px;">Status</th>
        <th style="color:#ff99cc;width:100px;font-size: 30px;">Action</th>
    </tr>
    <?php foreach($result as $row): ?>

    <tr>
        <td><?php echo e($row->id); ?></td>
         <td><?php echo e($row->genres); ?></td>
          <td><?php echo e($row->status); ?></td>
           <td style="width:200px"><a href="<?php echo e(url('genres/editgenres')); ?>/<?php echo e($row->id); ?>" style="text-decoration: none;">Edit</a>
           |
           <a href="<?php echo e(url('genres/deletegenres')); ?>/<?php echo e($row->id); ?>" style="text-decoration: none;">Delete</a>
           |
           <a href="<?php echo e(url('genres/changestatusgenres')); ?>/<?php echo e($row->id); ?>" style="text-decoration: none;"><?php if($row->status=='publish'): ?>
           Draft
           <?php endif; ?>
           <?php if($row->status=='draft'): ?>
           Publish
           <?php endif; ?>
           </a>
           </td></tr>
        <?php endforeach; ?>
          
   
</table>
 </div>  
</body>
</html>




<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class countermodel extends Model
{
    protected $table='countermodels';
}

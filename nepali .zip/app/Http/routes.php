<?php


Route::controller('admin','admincontroller');
Route::controller('category','categorycontroller');
Route::controller('movies','moviescontroller');
Route::controller('genres','genrescontroller');

Route::controller('login','logincontroller');
Route::controller('user','usercontroller');

Route::controller('test','testcontroller');

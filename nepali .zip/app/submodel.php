<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class submodel extends Model
{
    protected $table='submodels';
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class commentmodel extends Model
{
   protected $table='commentmodels';
}

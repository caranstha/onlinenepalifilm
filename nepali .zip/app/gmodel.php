<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gmodel extends Model
{
   protected $table='gmodels';
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ratemodel extends Model
{
   protected $table='ratemodels';
}

<?php echo $__env->make('admin/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="content">
<form action="<?php echo e(url('genres/addgenres')); ?>" method="POST">
     <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
    <p>Enter Genres name </p>
    <input type="text" name="genres">
    <select name='status'>
    <option value="publish">Publish</option>    
    <option value="draft">Draft</option>
    </select>
    <p><input type="submit" value="Add" name="add"></p>
</form>
</div>  
</body>
</html>